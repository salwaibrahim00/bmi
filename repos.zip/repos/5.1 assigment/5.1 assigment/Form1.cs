﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static final_project.Form1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace final_project
{
    public partial class Form1 : Form
    {






        int age;
        string gender;
        double weightKg, heightM;
        public class Customer
        {
            private string fname;
            private string lname;
            public Customer(string fn, string ln)
            {
                if (fn.Length == 0)
                {
                    MessageBox.Show("invalid fname, names set to Dana");
                    fname = "Dana";
                }
                else
                    fname = fn;
                if (ln.Length == 0)
                {
                    MessageBox.Show("invalid lname , name , name set to Sami");
                    lname = "Sami";
                }
                else
                    lname = ln;
            }
            public string Fname
            {
                get { return fname; }
                set { fname = value; }

            }
            // method to put customer name in a messagebox
            public void display()
            {
                MessageBox.Show(" customer name =" + fname + "" + lname);

            }
        }
        //create a BMI CALCULATOR
        public class BMICalculator
        {
            public double CalculateBMI(double height, double weight)

            {
                if (height == 0)
                {
                    MessageBox.Show("Invalid height; BMI cannot be calculated.");
                    return 0;
                }
                return weight / (height * height);
            }
            public string GetBMICategory(double bmi)
            {
                if (bmi < 18.5)
                    return "underweight";
                else if (bmi < 24.9)
                    return "normal weight";
                else if (bmi < 29.9)
                    return "overweight";
                else
                    return "obese";

            }//Method to put BMI information in a messagebox
            public void DisplayBMIInfo(double height, double weight)
            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategory(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}");
            }

        }
        // create BMI calculator for children by inherting from BMI calculator
        public class ChildrenBMICalculator : BMICalculator
        {
            public double CalculateBMI(double height, double weight, int age, string gender)
            {
                if (height <= 0 || weight <= 0)
                {

                    MessageBox.Show(" invalid height or weight; BMI  for children cannot be  calculated");
                    return 0;

                }
                return weight / (height * height);
            }
            // method to get the BMI category for children based on BMI value
            public string GetBMICategoryForChild(double bmi)
            {
                if (bmi < 12)
                    return "underweight";
                else if (bmi >= 12 && bmi < 17)
                    return "normal weight";
                else if (bmi >= 17 && bmi < 20)
                    return "overweight";
                else
                    return "obese";
            }


            public void DisplayBMIInfoForChild(double height, double weight, int age, string gender)

            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategoryForChild(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}\nAge:{age}\nGender: {gender}");
            }
        }
        // method to get the childs age from textbox control
        int GetChildAge()
        {
            if (int.TryParse(textBox8.Text, out int age))
            {
                return age;
            }
            else
            {
                MessageBox.Show("please enter a valid age");
                return 0;
            }
        }
        // method to get childs gender from radiobutoon controls
        string GetChildGender()
        {
            if (radioButton1.Checked)
            {
                return " male";

            }
            else if (radioButton2.Checked)
            {
                return " female";
            }
            MessageBox.Show("please select the childs gender.");
            return string.Empty;






        }

        // constructor for the form1 class
        public Form1(string s1 = "form1 init string")
        {
            InitializeComponent();
            textBox5.Text = s1;
            InitializeTabOrder();
            ChangeLabelColors();
        }
        // method to organize the tabindex property for form controls
        private void InitializeTabOrder()
        {
            // Set the TabIndex property for each control
            textBox1.TabIndex = 0;
            textBox2.TabIndex = 1;
            textBox3.TabIndex = 2;
            textBox4.TabIndex = 3;
            textBox5.TabIndex = 4;
            textBox6.TabIndex = 5;
            textBox7.TabIndex = 6;
            textBox8.TabIndex = 7;
            textBox9.TabIndex = 8;
            textBox10.TabIndex = 9;

            button1.TabIndex = 11;
            button2.TabIndex = 12;
            button3.TabIndex = 13;
            button4.TabIndex = 14;
            button5.TabIndex = 15;
            button6.TabIndex = 16;
            radioButton1.TabIndex = 17;

            radioButton2.TabIndex = 18;

            panel1.TabIndex = 19;
            panel2.TabIndex = 20;
            panel3.TabIndex = 21;
        }






        private void ChangeLabelColors()
        {
            // Iterate through all the controls on the form
            foreach (Control control in Controls)
            {
                if (control is Label)
                {
                    // Change the label's text color
                    ((Label)control).ForeColor = System.Drawing.Color.DarkBlue; // Set the desired color
                }
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            // Set a tooltip for the TextBox
            toolTip1.SetToolTip(textBox3, "This is a tooltip for the TextBox.");

            toolTip1.SetToolTip(textBox4, "This is a tooltip for the TextBox.");

            toolTip1.SetToolTip(textBox10, "This is a tooltip for the TextBox.");

            toolTip1.SetToolTip(textBox9, "This is a tooltip for the TextBox.");


            toolTip1.SetToolTip(textBox6, "This is a tooltip for the TextBox.");


            toolTip1.SetToolTip(textBox7, "This is a tooltip for the TextBox.");

            toolTip1.SetToolTip(textBox8, "This is a tooltip for the TextBox.");


            toolTip1.SetToolTip(textBox1, "This is a tooltip for the TextBox.");


            toolTip1.SetToolTip(textBox2, "This is a tooltip for the TextBox.");

            toolTip1.SetToolTip(textBox5, "This is a tooltip for the TextBox.");
            toolTip1.SetToolTip(panel2, "This is a tooltip for the TextBox.");

            toolTip1.SetToolTip(panel3, "This is a tooltip for the TextBox.");
            toolTip1.SetToolTip(panel1, "This is a tooltip for the TextBox.");
            toolTip1.SetToolTip(panel4, "This is a tooltip for the TextBox.");
        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string firstName = textBox1.Text;
            String lastname = textBox2.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();

        }
        // method triggered on button 2
        private void button2_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            String lastName = textBox2.Text;
            Customer customer = new Customer(firstName, lastName);
            customer.display();
            double height, weight;
            // check if the height and weight values are valid
            if (double.TryParse(textBox3.Text, out height) && double.TryParse(textBox4.Text, out weight))

            {
                BMICalculator bMICalculator = new BMICalculator();
                bMICalculator.DisplayBMIInfo(height, weight);
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        { 
        }


        private void panel1_MouseLeave(object sender, EventArgs e)
        {
            
        }

        private void panel2_MouseEnter(object sender, EventArgs e)
        {  
            
        }

        private void panel2_MouseLeave(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {

            // clear the value of various of all textbox controls
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox9.Clear();
            textBox11.Clear();
            textBox10.Clear();
            textBox11.Clear();

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            // convert pounds to kilograms and show the results in a messagebox five times
            if (double.TryParse(textBox10.Text, out double pounds))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 5 times
                {
                    double kilograms = pounds * 0.45359237;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($"i={i}pounds= {pounds},kilograms={kilograms:F2}", "answer");


                }
        }

        private void button6_Click(object sender, EventArgs e)
        {


            if (double.TryParse(textBox9.Text, out double inches))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 6 times
                {
                    double meters = inches * 0.0254;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($" Iteration :{i + 1} \nInches:{inches:F2}\nMeters:{meters:F2}", "Conversion Result");
                    if (meters > 100)
                    {
                        textBox9.BackColor = Color.DarkRed;
                    }
                }
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel3_MouseEnter(object sender, EventArgs e)
        {
           
        }

        private void panel3_MouseLeave(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {


            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox9.Clear();
            textBox11.Clear();
            textBox10.Clear();
            textBox11.Clear();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
           // create and show form2 with the text from textbox5
            Form f2 = new Form2(textBox5.Text);
            f2.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {
            // display information about BMI when label 11 clicked
            label11.Text = "BMI stands for body mass index, which is a measure of weight relative to height. A healthy BMI range is from 18.5 to 24.9123. A BMI below or above this range may indicate underweight or overweight, respectively, and may be associated with health risks such as diabetes, hypertension, and cardiovascular disease12. However, BMI is not the only factor that affects health, and other factors such as body fat distribution, muscle mass, and lifestyle should also be considered3. ";
             label11.Font = new Font("Arial", 12, FontStyle.Regular);
        }
        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            panel3.BackColor = Color.Beige;
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            panel4.BackColor = Color.Beige;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            panel2.BackColor = Color.Beige;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.BackColor = Color.Beige;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            string lastname = textBox2.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();
            double height, weight;
            // check if the enterd values for height and weight are valid
            if (double.TryParse(textBox6.Text, out height) && double.TryParse(textBox7.Text, out weight))
            {
                ChildrenBMICalculator bmiCalclator = new ChildrenBMICalculator();
                int age = GetChildAge();

                string gender = GetChildGender();
                // create a childrenbmicalculator instance and display bmi information for children 
                ChildrenBMICalculator bmiCalculator = new ChildrenBMICalculator();
                bmiCalculator.DisplayBMIInfoForChild(height, weight, age, gender);

            }
        }
    }
}




