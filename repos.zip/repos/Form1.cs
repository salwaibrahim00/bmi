﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace project_programming
{
    public partial class Form1 : Form
    {
        string textfile = "BMIS.txt";// The name of the  text file here 
        public Form1()
        {
            InitializeComponent();
        }
        private double RoundedNumber(double numberToRound)

        {
            return Math.Round(numberToRound, 2);
        }




        private void button1_Click(object sender, EventArgs e)
            
        {
            // check if textbox.1 text is not null or empty
            if(! string . IsNull0rEmpty(textbox1.text) )
            // round a number to two decimal places and display it in textbox
            if (double.TryParse(textBox1.Text, out double numberToRound))
            {
                double roundedvalue = RoundedNumber(numberToRound);
                textBox1.Text = roundedvalue.ToString("0.00");//display with 2 decimal places
                    {
                                           }

                        
                    {
                        
                        
                    }
                    

            }
            // change the background color of the butoon to brown
            button1.BackColor = Color.Brown;// set the background color to brown

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // convert pounds to kilograms and show the results in a messagebox five times
            if (double.TryParse(textBox2.Text, out double pounds))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 5 times
                {
                    double kilograms = pounds * 0.45359237;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($"i={i}pounds= {pounds},kilograms={kilograms:F2}","answer");

                }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            { // read and display the contents of the "BMIS.txt" file
                using (StreamReader reader = new StreamReader(textfile))
                {

                    string line = reader.ReadLine();

                    while ((line = reader.ReadLine()) != null)
                    {
                        line = line.Trim();
                        //Display each line from the file in a message box
                        MessageBox.Show(line);
                    }
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Append text from textbox 3 to the end of the "BMIS.txt" file.

            using (StreamWriter writer = File.AppendText(textfile))
            {
                writer.Write(textBox3.Text + Environment.NewLine);
                // close the steamwriter here to ensure proper disposal
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Allow the user to select a text file , read its content and displayit im textbox1 and a message box 
            openFileDialog1 = new OpenFileDialog();// declare openFileDialog1 locally.
            openFileDialog1.Title = "choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.ShowDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var filepath = openFileDialog1.FileName;

                using (StreamReader reader = new StreamReader(filepath))
                {
                    var filecontent = reader.ReadToEnd();
                    textBox1.Text = (filecontent);
                    //Display the files content in a message box
                    MessageBox.Show(filecontent, "file content");
                }
            }
        }

        private void button1_SystemColorsChanged(object sender, EventArgs e)
        {

        }
    }
}