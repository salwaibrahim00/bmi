﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5._1_assigment
{
    public partial class Form1 : Form
    {

        double[] nums = new double[3];

        string textfile = "HEALTHY.txt";// The name of the  text file here 
        double weightKg, heightM;
        int TextBox;
        string ToolTip;
        public class Customer
        {
            private string fname;
            private string lname;
            public Customer(string fn, string ln)
            {
                if (fn.Length == 0)
                {
                    MessageBox.Show("invalid fname, name set to Dana");
                    fname = "Dana";
                }
                else
                    fname = fn;
                if (ln.Length == 0)
                {
                    MessageBox.Show("invalid lname , name , name set to Sami");
                    lname = "Sami";
                }
                else
                    lname = ln;
            }
            public string Fname
            {
                get { return fname; }
                set { fname = value; }

            }
            public void display()
            {
                MessageBox.Show(" customer name =" + fname + "" + lname);
            }
        }


        public class BMICalculator
        {
            public double CalculateBMI(double height, double weight)

            {
                if (height == 0)
                {
                    MessageBox.Show("Invalid height; BMI cannot be calculated.");
                    return 0;
                }
                return weight / (height * height);
            }
            public string GetBMICategory(double bmi)
            {
                if (bmi < 18.5)
                    return "underweight";
                else if (bmi < 24.9)
                    return "normal weight";
                else if (bmi < 29.9)
                    return "overweight";
                else
                    return "obese";

            }
            public void DisplayBMIInfo(double height, double weight)
            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategory(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}");
            }
        }
        public class ChildrenBMICalculator : BMICalculator
        {
            public double CalculateBMI(double height, double weight)
            {
                if (height <= 0 || weight <= 0)
                {

                    MessageBox.Show(" invalid height or weight; BMI  for children cannot be  calculated");
                    return 0;

                }
                return weight / (height * height);
            }
            public string GetBMICategoryForChild(double bmi)
            {
                if (bmi < 12)
                    return "underweight";
                else if (bmi >= 12 && bmi < 17)
                    return "normal weight";
                else if (bmi >= 17 && bmi < 20)
                    return "overweight";
                else
                    return "obese";
            }


            public void DisplayBMIInfoForChild(double height, double weight, int age, string gender)

            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategoryForChild(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}\nAge:{age}\nGender: {gender}");
            }



        }

        int GetChildAge()
        {
            if (int.TryParse(textBox7.Text, out int age))
            {
                return age;
            }
            else
            {
                MessageBox.Show("please enter a valid age");
                return 0;
            }
        }
        string GetChildGender()
        {
            if (radioButton1.Checked)
            {
                return " male";

            }
            else if (radioButton2.Checked)
            {
                return " female";
            }
            MessageBox.Show("please select the childs gender.");
            return string.Empty;



        }




        public Form1(string s1 = "form 1 init string")
        {
            InitializeComponent();
            textBox20.Text = s1;


        }

        private void button1_Click(object sender, EventArgs e)

        {


            string firstName = textBox1.Text;
            String lastname = textBox2.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();
            {



            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            textBox1.BackColor = Color.Blue;// change the background color blue
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.BackColor = Color.DarkGreen;// change the backgroung color to darkgreen
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.BackColor = Color.Orange;// change the backgroung color to orange

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            String lastName = textBox2.Text;
            Customer customer = new Customer(firstName, lastName);
            customer.display();
            double height, weight;
            if (double.TryParse(textBox3.Text, out height) && double.TryParse(textBox4.Text, out weight))

            {
                BMICalculator bMICalculator = new BMICalculator();
                bMICalculator.DisplayBMIInfo(height, weight);
                {

                    {


                        {





                        }
                    }
                }
            }
        }





        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            // convert pounds to kilograms and show the results in a messagebox five times
            if (double.TryParse(textBox8.Text, out double pounds))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 5 times
                {
                    double kilograms = pounds * 0.45359237;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($"i={i}pounds= {pounds},kilograms={kilograms:F2}", "answer");

                }
        }

        private void button4_Click(object sender, EventArgs e)
        {


            if (double.TryParse(textBox9.Text, out double inches))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 2 times
                {
                    double meters = inches * 0.0254;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($" Iteration :{i + 1} \nInches:{inches:F2}\nMeters:{meters:F2}", "Conversion Result");
                    if (meters > 100)
                    {
                        textBox9.BackColor = Color.AliceBlue;
                    }
                }
        }

        private void button5_Click(object sender, EventArgs e)

        {
            string firstName = textBox1.Text;
            string lastname = textBox2.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();
            double height, weight;
            if (double.TryParse(textBox5.Text, out height) && double.TryParse(textBox6.Text, out weight))
            {
                ChildrenBMICalculator bmiCalclator = new ChildrenBMICalculator();
                int age = GetChildAge();

                string gender = GetChildGender();

                ChildrenBMICalculator bmiCalculator = new ChildrenBMICalculator();
                bmiCalculator.DisplayBMIInfoForChild(height, weight, age, gender);



            }
        }

        private void button6_Click(object sender, EventArgs e)
        {


        }

        private void button7_Click(object sender, EventArgs e)
        {
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)

        {


        }




        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();

        }

       

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {




        }

        private void button11_Click(object sender, EventArgs e)
        {

        }









        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }


        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void button12_Click_1(object sender, EventArgs e)
        {



        }




        private void textBox20_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }


       

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {



        }

        private void tableLayoutPanel6_Paint(object sender, PaintEventArgs e)
        {


        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            label9.Text = " This bmi calculator is for adults checks your bmi in your body according to weight and height";

            label9.Location = new Point(panel1.Location.X, panel1.Location.Y + panel1.Height + 5);
            label9.Visible = true;
        }

        private void panel1_MouseLeave(object sender, EventArgs e)
        {
            label9.Visible = false;
        }

        

        
        

        private void panel2_MouseEnter(object sender, EventArgs e)
        {

            label15.Text = " This  calculator is to convert pounds to kilogram and inches to meters";

            label15.Location = new Point(panel1.Location.X, panel1.Location.Y + panel1.Height + 5);
            label15.Visible = true;
        }

        private void panel2_MouseLeave(object sender, EventArgs e)
        {

            label15.Visible = false;
        }

        private void panel3_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = " This bmi calculator is for children checks your bmi in your body according to weight and height";

            label1.Location = new Point(panel1.Location.X, panel1.Location.Y + panel1.Height + 5);
            label1.Visible = true;
        }

        private void panel3_MouseLeave(object sender, EventArgs e)
        {

            label1.Visible = false;
        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(textBox1.Text);
            f2.Show();
            this.Hide();
        }
    }
}     